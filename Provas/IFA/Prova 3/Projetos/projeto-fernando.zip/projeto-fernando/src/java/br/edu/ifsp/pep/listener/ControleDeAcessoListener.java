package br.edu.ifsp.pep.listener;

import br.edu.ifsp.pep.controller.LoginController;
import br.edu.ifsp.pep.modelo.TipoUsuario;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.faces.context.FacesContext;
import jakarta.faces.event.PhaseEvent;
import jakarta.faces.event.PhaseId;
import jakarta.faces.event.PhaseListener;
import jakarta.inject.Inject;
import java.io.IOException;


public class ControleDeAcessoListener implements PhaseListener{

    @Inject
    private LoginController loginController;
    
    @Override
    public void afterPhase(PhaseEvent event) {
        System.out.println("Apos a fase: " + event.getPhaseId());
        
        FacesContext ctx = event.getFacesContext();
        String pagina = ctx.getViewRoot().getViewId();
        
        // venda so precisa de login, pode ser qualquer um.
        if (pagina.equals("/venda.xhtml")){
            System.out.println("Entrou na verificaçao de login");
            
            if (loginController.getUsuarioLogado() == null){
                redirecionar(ctx, "/login.xhtml");
            }else{
                System.out.println("Acesso permitido");
            }
            
        }
        
        // aqui precisa ser admin
        if (pagina.equals("/usuario/cadastro.xhtml") || pagina.equals("/curso/cadastro.xhtml")){
            System.out.println("Entrou na verificaçao de login");
            
            if (loginController.getUsuarioLogado() == null){
                redirecionar(ctx, "/login.xhtml");
            }else{
                if (loginController.getUsuarioLogado()
                        .getNivelAcesso().equals(TipoUsuario.ADMIN)) {
                    
                    // corrige o problema de ficar mandando acesso garantido toda hora.
                    if(!ctx.isPostback()){
                        Mensagem.sucesso("Acesso garantido");
                    }
                    
                }else{
                    Mensagem.erro("Acesso negado");
                    redirecionar(ctx, "/acessonegado.xhtml");
                }
            }
        }
    }

    @Override
    public void beforePhase(PhaseEvent event) {
        System.out.println("Antes da fase" + 
                event.getPhaseId());
    }

    @Override
    public PhaseId getPhaseId() {
        return PhaseId.ANY_PHASE;
    }
    
    private void redirecionar(FacesContext ctx, String pagina){
        try {
            String projeto = ctx.getExternalContext().getRequestContextPath();
            ctx.getExternalContext().redirect(projeto + pagina);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    
    
}
