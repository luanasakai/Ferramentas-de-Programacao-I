package br.edu.ifsp.pep.modelo;

public enum TipoUsuario {
    ADMIN, USUARIO;
}
