package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.EntidadeDAO;
import br.edu.ifsp.pep.entity.Entidade;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author aluno
 */
@Named
/*CRIA NOVA REQUISICAO = NEW OBJETO
  OBJETO SESSIONSCOPED SO EXISTE ENQUANTO A SESSAO ESTIVER ATIVA
//@SessionScoped*/
/*As classes (controller) sao instanciadas pelo servidor (neste caso o glassfish)*/
@RequestScoped
public class EntidadeController implements Serializable{
    
    @Inject()
    private EntidadeDAO entidadeDAO;    
    
    private List<Entidade> entidades;
    private Entidade entidade = new Entidade();
    
    public String inserir() {

        if (entidade.getNome().length() < 5) {
            Mensagem.atencao("O Nome deve ter pelo menos 5 caracteres.");
            return null;
        }

        entidadeDAO.inserir(entidade);
        entidade = new Entidade();
        Mensagem.sucesso("Entidade Cadastrada.");
        
        return "/entidade/lista";//retorna para a pagina de lista automaticamente
    }
    
     public List<Entidade> getEntidades() {
        System.out.println("metodo getEntidades");
        if (this.entidades == null) {
            System.out.println("Acessando banco de dados...");
            this.entidades = entidadeDAO.buscarTodas();
        }

        return this.entidades;
    }
}
