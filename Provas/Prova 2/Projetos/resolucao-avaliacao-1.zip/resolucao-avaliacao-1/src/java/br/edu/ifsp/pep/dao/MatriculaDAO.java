package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entidade.Matricula;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author aluno
 */
@Stateless
public class MatriculaDAO extends AbstractDAO<Matricula> {
    
    public List<Matricula> buscarPorIdAluno(Integer ano, Integer semestre, Integer idAluno) {
        EntityManager em = getEntityManager();
        TypedQuery<Matricula> query = em.createNamedQuery("Matricula.buscarPorAluno", Matricula.class);
        query.setParameter("ano", ano);
        query.setParameter("semestre", semestre);
        query.setParameter("idAluno", idAluno);
        
        return query.getResultList();
    }
}
