package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entity.Projeto;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author aluno
 */
@Stateless
public class ProjetoDAO extends AbstractDAO<Projeto>{
    
    public List<Projeto> buscarTodas() {
        
        EntityManager em = getEntityManager();
        TypedQuery<Projeto> query = em.createNamedQuery("Projeto.buscarTodas", Projeto.class);
        
        return query.getResultList();
        
    }
    
    public Projeto buscarPeloId(Integer id){
        EntityManager em = getEntityManager();
        return em.find(Projeto.class, id);
    }
}
