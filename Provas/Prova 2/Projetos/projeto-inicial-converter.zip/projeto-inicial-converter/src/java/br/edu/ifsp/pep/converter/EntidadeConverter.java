/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.pep.converter;

import br.edu.ifsp.pep.dao.EntidadeDAO;
import br.edu.ifsp.pep.entity.Entidade;
import jakarta.enterprise.inject.spi.CDI;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.inject.Inject;

/**
 *
 * @author aluno
 */
//toda vez que precisar converter string para Entidade ele utiliza a classe Entidade
/*ESTA CLASSE EH UTILIZADA NA CLASSES CONTROLLER */
@FacesConverter(forClass = Entidade.class)
public class EntidadeConverter implements Converter<Entidade>{
    @Inject
    private EntidadeDAO entidadeDAO;
    
    @Override
    public Entidade getAsObject(FacesContext fc, UIComponent uic, String string) {
        if(string == null){
            return null;
        }
        
        //obtem o DAO
       entidadeDAO = CDI.current().select(EntidadeDAO.class).get();
        
        //buscar no BD
        return entidadeDAO.buscarPeloId(Integer.valueOf(string));
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Entidade e) {
        
        if(e == null){
            return null;
        }
        
        return String.valueOf(e.getCodigo());
        
    }
    
}
