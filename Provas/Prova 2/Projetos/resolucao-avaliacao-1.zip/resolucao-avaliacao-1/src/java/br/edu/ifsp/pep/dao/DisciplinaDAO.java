package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entidade.Disciplina;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author aluno
 */
@Stateless
public class DisciplinaDAO extends AbstractDAO<Disciplina> {
    
    public List<Object[]> quantidadePorCurso() {
        EntityManager em = getEntityManager();
        TypedQuery<Object[]> query = em.createNamedQuery("Disciplina.quantidadePorCurso", Object[].class);
        
        return query.getResultList();
    }
}
