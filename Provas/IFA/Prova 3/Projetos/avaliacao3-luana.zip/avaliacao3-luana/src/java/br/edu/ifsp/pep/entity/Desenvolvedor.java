/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.pep.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author aluno
 */

@Entity
@Table(name = "desenvolvedor")
@NamedQueries(value = {
    @NamedQuery(name = "Desenvolvedor.buscarTodas", query = "FROM Desenvolvedor d"),
    @NamedQuery(name = "Desenvolvedor.buscarPeloId", query = "FROM Desenvolvedor d WHERE d.codigo = :id"),
})
public class Desenvolvedor  implements Serializable{
    
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo")
    private Integer codigo;

    @Column(name = "nome", nullable = false, length = 80)
    private String nome;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "desenvolvedor")
    private List<Alocacao> alocacoes;

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Alocacao> getAlocacoes() {
        return alocacoes;
    }

    public void setAlocacoes(List<Alocacao> alocacoes) {
        this.alocacoes = alocacoes;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.codigo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Desenvolvedor other = (Desenvolvedor) obj;
        return Objects.equals(this.codigo, other.codigo);
    }
    
    @Override
    public String toString() {
        return "Desenvolvedor{" + "codigo=" + codigo + ", nome=" + nome + ", alocacoes=" + alocacoes + '}';
    }

}
