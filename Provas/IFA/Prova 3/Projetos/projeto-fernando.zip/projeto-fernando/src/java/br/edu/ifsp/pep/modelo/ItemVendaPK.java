package br.edu.ifsp.pep.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;


@Embeddable
public class ItemVendaPK implements Serializable{
    
    @Column(name = "id_curso", nullable = false)
    private Integer curso;
    
    @Column(name = "id_venda", nullable = false)
    private Integer venda;

    public Integer getCurso() {
        return curso;
    }

    public void setCurso(Integer curso) {
        this.curso = curso;
    }

    public Integer getVenda() {
        return venda;
    }

    public void setVenda(Integer venda) {
        this.venda = venda;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + Objects.hashCode(this.curso);
        hash = 83 * hash + Objects.hashCode(this.venda);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemVendaPK other = (ItemVendaPK) obj;
        if (!Objects.equals(this.curso, other.curso)) {
            return false;
        }
        return Objects.equals(this.venda, other.venda);
    }

    @Override
    public String toString() {
        return "ItemVendaPK{" + "curso=" + curso + ", venda=" + venda + '}';
    }
    
    
}
