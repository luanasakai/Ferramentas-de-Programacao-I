package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Curso;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class CursoDAO extends AbstractDAO<Curso>{
    
    public List<Curso> buscarTodos(){
        EntityManager em = getEntityManager();
        TypedQuery<Curso> q = em.createNamedQuery("Curso.buscarTodos",
                Curso.class);
        return q.getResultList();
    }
    
    public List<Curso> buscarPorNome(String nome){
        EntityManager em = getEntityManager();
        TypedQuery<Curso> q = em.createNamedQuery("Curso.buscarPeloNome",
                Curso.class);
        q.setParameter("nome", "%" + nome + "%");
        return q.getResultList();
    }

    public Curso buscarPeloId(Integer id){
        EntityManager em = getEntityManager();
        return em.find(Curso.class, id);
    }
}
