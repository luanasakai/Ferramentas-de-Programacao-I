package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.CursoDAO;
import br.edu.ifsp.pep.modelo.Curso;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


@Named(value = "cursoController")
@SessionScoped
public class CursoController implements Serializable{
    
    
    private double desconto = 0.0;
    private BigDecimal total = BigDecimal.ZERO;
    
    // o curso selecionado pelo usuario
    private Curso curso;
    
    // aqui sao os cursos selecionados para a compra.
    private List<Curso> cursos;
    
    // aqui sao os cursos vindos do banco.
    private List<Curso> listaCursos;
    
    @Inject
    private CursoDAO cursoDAO;

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public double getDesconto() {
        return desconto;
    }

    public void setDesconto(double desconto) {
        this.desconto = desconto;
    }
    

    public CursoController() {
        curso = new Curso();
    }
    
    public void falar(){
        System.out.println("lista:" + cursos);
        System.out.println("desconto: " + desconto);
    }
    
    // vai para a página de pagamento.
    public String pagamento(){
        if (cursos.isEmpty()){
            Mensagem.erro("Nao ha cursos no carrinho");
            return "";
        }else{
            total = BigDecimal.valueOf(0.0);

            for (Curso c : cursos) {
                total = total.add(c.getValor());
            }
            falar();
            return "/pagamento.xhtml";
        }
    }
    
    public String finalizar(){
        
        BigDecimal totalComDesconto = 
                BigDecimal.ONE.subtract(BigDecimal.valueOf(desconto)).multiply(total);
        System.out.println("Total com desconto: " + totalComDesconto);
                falar();
        return "/index.xhtml";
    }

    
    public void adicionarNaLista(){
        if (cursos.contains(curso)){
            Mensagem.erro("curso ja escolhido!");
        }else{
            cursos.add(curso);
            curso = new Curso();
        }
    }
    
    public void removerDaLista(Curso c){
        System.out.println("Contem? " + cursos.contains(c));
        System.out.println("Quem e? " + c);
        
        
        if (cursos.contains(c)){
            cursos.remove(c);
        }else{
            Mensagem.erro("Nao existe na lista");
        }
    }
    
    public void cadastrar(){
        System.out.println("------> INSERIR <------");
        try {
            cursoDAO.inserir(curso);
            Mensagem.sucesso("Curso Cadastrado.");
            listaCursos = null;
            System.out.println("Lista de cursos:" + listaCursos);
        } catch (Exception e) {
            Mensagem.erro("Ocorreu um erro.");
        }
    }

    public void remover(Curso c){
        try {
            cursoDAO.remover(c);
            listaCursos = null;
            Mensagem.sucesso("Removido.");
        } catch (Exception e) {
            Mensagem.erro("Algo deu errado.");
        }
    }
    
    public Curso getCurso() {
        if (curso == null) {
            curso = new Curso();
        }
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public List<Curso> getCursos() {
        if (cursos != null){
            return cursos;
        }
        cursos = new ArrayList<>();
        return cursos;
    }

    public void setCursos(List<Curso> cursos) {
        this.cursos = cursos;
    }

    public List<Curso> getListaCursos() {
        if (listaCursos == null) {
            listaCursos = cursoDAO.buscarTodos();
        }
        return listaCursos;
    }

    public void setListaCursos(List<Curso> listaCursos) {
        this.listaCursos = listaCursos;
    }

    
    public List<Curso> buscarPeloNome(String nome){
        return cursoDAO.buscarPorNome(nome);
    }
    
    
}
