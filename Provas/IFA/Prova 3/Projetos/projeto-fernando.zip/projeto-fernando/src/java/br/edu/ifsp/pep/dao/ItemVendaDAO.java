package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.ItemVenda;
import jakarta.ejb.Stateless;

@Stateless
public class ItemVendaDAO extends AbstractDAO<ItemVenda>{
    
    
}
