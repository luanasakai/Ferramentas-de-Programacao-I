package br.edu.ifsp.pep.controller;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;

/**
 *
 * @author sakai
 */
@Named
//@RequestScoped
//@ViewScoped //Enquanto nao trocar de pagina ou atualizar a pagina
@SessionScoped
public class CursoController  implements Serializable {
    
}
