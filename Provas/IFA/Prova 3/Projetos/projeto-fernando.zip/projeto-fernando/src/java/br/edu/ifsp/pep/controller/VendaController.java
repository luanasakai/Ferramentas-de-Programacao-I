package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.ItemVendaDAO;
import br.edu.ifsp.pep.dao.VendaDAO;
import br.edu.ifsp.pep.modelo.Curso;
import br.edu.ifsp.pep.modelo.ItemVenda;
import br.edu.ifsp.pep.modelo.Venda;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;



@Named(value = "vendaController")
@SessionScoped
public class VendaController implements Serializable{
    
    @Inject
    private VendaDAO vendaDAO;
    
    @Inject
    private ItemVendaDAO itemVendaDAO;
    
    @Inject
    private CursoController cursoController;
    
    private Venda venda;
    
    // os cursos do carrinho
    private List<Curso> cursosEscolhidos;
    

    public Venda getVenda() {
        if (venda == null){
            venda = new Venda();
        }
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    // insere a venda para poder inserir os item venda.
    public Venda cadastrarVenda(){
        Venda v = new Venda();
        // pega o desconto la do curso controller.
        Double desconto = cursoController.getDesconto();
        v.setDesconto(desconto);
        
        // valor total ja com o desconto
        BigDecimal fator = BigDecimal.ONE.subtract(BigDecimal.valueOf(desconto));
        BigDecimal total = cursoController.getTotal();
        
        // coloca o valor total
        v.setValorTotal(total.multiply(fator));
        
        try {
            vendaDAO.inserir(v);
        } catch (Exception e) {
            Mensagem.erro("Algo deu errado ao cadastrar a venda");
            System.out.println("ERRO NA VENDA");
        }
        
        return v;
    }
    
    public void cadastrarItemVenda(Venda v, Curso c){
        
        ItemVenda iv = new ItemVenda();
        
        // cadastra com o valor de cada curso sem o desconto.
        // ja que o desconto eh aplicado no total da venda.
        // qualquer coisa mudar a logica aqui.
        iv.setCurso(c);
        iv.setVenda(v);
        iv.setValor(c.getValor());
        
        try {
            itemVendaDAO.inserir(iv);
        } catch (Exception e) {
            Mensagem.erro("Algo deu errado");
            System.out.println("erro");
        }
    }
    
    
    public String finalizar(){
        Venda v = cadastrarVenda();
        cursosEscolhidos = cursoController.getCursos();
        
        for(Curso c : cursosEscolhidos){
            cadastrarItemVenda(v, c);
        }
        
        cursoController.setCursos(null);
        return "/index.xhtml";
    }
    
    
}
