/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.CursoDAO;
import br.edu.ifsp.pep.dao.VendaDAO;
import br.edu.ifsp.pep.entity.Curso;
import br.edu.ifsp.pep.entity.Desconto;
import br.edu.ifsp.pep.entity.ItemVenda;
import br.edu.ifsp.pep.entity.Venda;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sakai
 */
@Named
//@RequestScoped
//@ViewScoped //Enquanto nao trocar de pagina ou atualizar a pagina
@SessionScoped
public class VendaController implements Serializable {
    
    @Inject
    private VendaDAO vendaDAO;
    
    @Inject
    private CursoDAO cursoDAO;
    
    private Desconto descontoSelecionado;
    private double valorTotal=0;
    private double valorFinal=0;
    
    private Venda venda = new Venda();
    private Curso curso = new Curso();
    private ItemVenda item = new ItemVenda();
    private List<ItemVenda> itensVenda = new ArrayList<>();
    private List<Desconto> listaDescontos; 
    
    public void adicionar() {
        item.setVenda(venda);
        item.setCurso(curso);
        item.setPreco(item.getCurso().getValor());
        itensVenda.add(item);
        valorTotal += item.getPreco().doubleValue();
        valorFinal = valorTotal;
        Mensagem.sucesso("Curso Cadastrado!");
        
        item = new ItemVenda();
        curso = new Curso();
    }
    
    //remove item da lista de produtos selecionados
    public void excluir(ItemVenda item){
          itensVenda.remove(item);
          valorTotal -= curso.getValor().doubleValue();
          valorFinal = valorTotal;
          Mensagem.sucesso("Item removido.");
    }
    
    public String finalizar() {

        try {
            venda.setData(LocalDateTime.now());
            venda.setItens(itensVenda);
            
            //persiste todos os cursos selecionadas
            for(ItemVenda it: itensVenda){
                cursoDAO.inserir(it.getCurso());
            }
            
            vendaDAO.inserir(venda);
            Mensagem.sucesso("Venda finalizada.");

            //Iniciar nova venda
            venda = new Venda();
            itensVenda = new ArrayList<>();
            descontoSelecionado = null;

            return "/index";
        } catch (Exception ex) {
            ex.printStackTrace();
            Mensagem.erro(ex.getMessage());
        }
        return null;
    }
    
    // Método que o JSF chama para preencher a lista no XHTML
    public Desconto[] getListaDescontos() {
        return Desconto.values();
    }

    // Listener do AJAX (deve ser void)
    public void calcularTotalComDesconto() {
        double subtotal = this.valorTotal;
        // Aplica o desconto se houver algum selecionado
        if (descontoSelecionado != null) {
            this.valorFinal = subtotal - (subtotal * descontoSelecionado.getPercentual());
        }
    }
    
    // Getters e Setters
    public Desconto getDescontoSelecionado() {
        return descontoSelecionado;
    }

    public void setDescontoSelecionado(Desconto descontoSelecionado) {
        this.descontoSelecionado = descontoSelecionado;
    }

    public double getValorTotal() {
        return valorTotal;
    }
    public VendaDAO getVendaDAO() {
        return vendaDAO;
    }

    public void setVendaDAO(VendaDAO vendaDAO) {
        this.vendaDAO = vendaDAO;
    }

    public CursoDAO getCursoDAO() {
        return cursoDAO;
    }

    public void setCursoDAO(CursoDAO cursoDAO) {
        this.cursoDAO = cursoDAO;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public ItemVenda getItem() {
        return item;
    }

    public void setItem(ItemVenda item) {
        this.item = item;
    }

    public List<ItemVenda> getItensVenda() {
        return itensVenda;
    }

    public void setItensVenda(List<ItemVenda> itensVenda) {
        this.itensVenda = itensVenda;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public double getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(double valorFinal) {
        this.valorFinal = valorFinal;
    }
    
    
}
