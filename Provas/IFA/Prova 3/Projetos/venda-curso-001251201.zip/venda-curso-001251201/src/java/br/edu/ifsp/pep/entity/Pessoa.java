package br.edu.ifsp.pep.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "pessoa")
public class Pessoa  implements Serializable {
    
    @Id //chave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY) //auto increment
    @Column(name = "codigo")
    private Integer codigo;

    @Column(name = "nome", nullable = false, length = 80)
    /*
    name -> nome do atributo no banco de dados.
    nullable -> define se o atributo pode se null.
    length -> tamanho do varchar.
     */
    private String nome;

    @Column(name = "data_nascimento", nullable = false)
    private LocalDate dataNascimento;

    @Column(name = "email", nullable = false, length = 80, unique = true)
    //unique -> define se o atributo pode nao pode ser repetido (unico).ú
    private String email;
    
    /*@Column(name = "salario", nullable = false, scale = 2, precision = 8)
   
    precision -> tamanho do valor decimal.
    scale -> quantidade de casas decimais.
     
    private D salario;*/

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Pessoa{" + "codigo=" + codigo + ", nome=" + nome + ", dataNascimento=" + dataNascimento + ", email=" + email + '}';
    }
}
