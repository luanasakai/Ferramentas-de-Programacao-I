package br.edu.ifsp.pep.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;



@Table(name = "usuario")
@Entity
@NamedQueries(value = {
    @NamedQuery(name = "Usuario.buscarTodos",
            query = "select u from Usuario u"),
    @NamedQuery(name = "Usuario.buscarLogin",
            query = "select u from Usuario u where u.email = :email and"
                    + " u.senha = :senha")
})
public class Usuario implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo")
    private Integer codigo;
    
    @Column(name = "email", length = 60, nullable = false, unique = true)
    private String email;
    
    @Column(name = "senha", length = 30, nullable = false)
    private String senha;
    
    @Column(name = "nivel_acesso", nullable = false)
    @Enumerated(EnumType.STRING)
    private TipoUsuario nivelAcesso;

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public TipoUsuario getNivelAcesso() {
        return nivelAcesso;
    }

    public void setNivelAcesso(TipoUsuario nivelAcesso) {
        this.nivelAcesso = nivelAcesso;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.codigo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return Objects.equals(this.codigo, other.codigo);
    }

    @Override
    public String toString() {
        return "Usuario{" + "codigo=" + codigo + ", email=" + email + ", senha=" + senha + ", nivelAcesso=" + nivelAcesso + '}';
    }
    
    
}
