package br.edu.ifsp.pep.entidade;

/**
 *
 * @author aluno
 */
public enum StatusMatricula {
    Aprovado, Reprovado, Cancelada, Cursando
}
