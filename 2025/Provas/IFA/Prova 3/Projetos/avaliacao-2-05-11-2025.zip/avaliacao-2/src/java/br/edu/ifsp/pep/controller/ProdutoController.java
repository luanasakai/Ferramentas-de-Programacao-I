package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.CategoriaDAO;
import br.edu.ifsp.pep.dao.ProdutoDAO;
import br.edu.ifsp.pep.entidade.Categoria;
import br.edu.ifsp.pep.entidade.Produto;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.List;

@Named
@RequestScoped
public class ProdutoController {

    @Inject
    private CategoriaDAO categoriaDAO;

    @Inject
    private ProdutoDAO produtoDAO;

    private Categoria categoria;

    //Data Table - listagem
    private List<Produto> produtos;

    //Cadastro
    private Produto produto = new Produto();

    public List<Produto> getProdutos() {
        if (this.produtos == null) {
            this.produtos = produtoDAO.buscarTodos();
        }
        return produtos;
    }

    public void filtrar() {
        if (categoria != null) {
            this.produtos = produtoDAO.buscarPelaCategoria(categoria.getId());
        } else {
            this.produtos = null;
        }
    }

    public String inserir() {

        if (produto.getNome().length() < 5) {
            Mensagem.erro("O Nome do produto deve ter pelo menos 5 caracteres.");
            return null;
        }

        produtoDAO.inserir(produto);
        this.produto = new Produto();
        Mensagem.sucesso("Produto cadastrado.");

        return "/produto/lista";

    }

    public List<Categoria> buscarCategorias() {
        return categoriaDAO.buscarTodas();
    }

    public List<Categoria> buscarCategoriaPeloNome(String query) {
        return categoriaDAO.buscarPeloNome(query);
    }

    public void excluir(Produto produto) {
        produtoDAO.remover(produto);
        Mensagem.sucesso("Produto excluido.");
        this.produtos = null; //Para poder atualizar a dataTable
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

}
