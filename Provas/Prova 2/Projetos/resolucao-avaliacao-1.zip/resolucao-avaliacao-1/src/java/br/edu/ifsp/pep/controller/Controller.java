package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.AlunoDAO;
import br.edu.ifsp.pep.dao.CursoDAO;
import br.edu.ifsp.pep.dao.DisciplinaDAO;
import br.edu.ifsp.pep.dao.MatriculaDAO;
import br.edu.ifsp.pep.entidade.Aluno;
import br.edu.ifsp.pep.entidade.Curso;
import br.edu.ifsp.pep.entidade.Disciplina;
import br.edu.ifsp.pep.entidade.Matricula;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author aluno
 */
@Named
@SessionScoped
public class Controller implements Serializable {
    
    @Inject
    private AlunoDAO alunoDAO;
    @Inject
    private CursoDAO cursoDAO;
    @Inject
    private DisciplinaDAO disciplinaDAO;
    @Inject
    private MatriculaDAO matriculaDAO;
    
    
    public void inserir() {
        
        
        Curso c1 = new Curso("Ciencia da Computacao");
        cursoDAO.inserir(c1);
        Curso c2 = new Curso("Engenharia Eletrica");
        cursoDAO.inserir(c2);
        
        Aluno a1 = new Aluno("Maria", c1);
        alunoDAO.inserir(a1);
        Aluno a2 = new Aluno("Joao", c1);
        alunoDAO.inserir(a2);
        Aluno a3 = new Aluno("Carolina", c2);
        alunoDAO.inserir(a3);
        Aluno a4 = new Aluno("Vitor", c2);
        alunoDAO.inserir(a4);
        
        Disciplina d1 = new Disciplina("Disciplina 1", c1);
        disciplinaDAO.inserir(d1);
        Disciplina d2 = new Disciplina("Disciplina 2", c1);
        disciplinaDAO.inserir(d2);
        Disciplina d3 = new Disciplina("Disciplina 3", c2);
        disciplinaDAO.inserir(d3);
        Disciplina d4 = new Disciplina("Disciplina 4", c2);
        disciplinaDAO.inserir(d4);
        
        
        Matricula m1 = new Matricula(2025, 1, a1, d1);
        matriculaDAO.inserir(m1);
        Matricula m2 = new Matricula(2025, 1, a1, d2);
        matriculaDAO.inserir(m2);
        Matricula m3 = new Matricula(2025, 1, a2, d1);
        matriculaDAO.inserir(m3);
        Matricula m4 = new Matricula(2025, 1, a3, d3);
        matriculaDAO.inserir(m4);
        Matricula m5 = new Matricula(2025, 1, a3, d4);
        matriculaDAO.inserir(m5);
        Matricula m6 = new Matricula(2025, 1, a4, d3);
        matriculaDAO.inserir(m6);
        Matricula m7 = new Matricula(2025, 1, a4, d4);
        matriculaDAO.inserir(m7);
    }
    
    public void exibir() {
        
        Curso curso = cursoDAO.buscarPorId(1);
        List<Aluno> alunos = alunoDAO.buscarPorCurso(curso);
        System.out.println("Alunos do Curso com id 1");
        System.out.println(alunos);

        curso = cursoDAO.buscarPorId(2);
        alunos = alunoDAO.buscarPorCurso(curso);
        System.out.println("Alunos do Curso com id 2");
        System.out.println(alunos);

        alunos = alunoDAO.buscarPorIdCurso(1);
        System.out.println("Alunos do Curso com id 1");
        System.out.println(alunos);
        
        System.out.println("--------------------------------");
        
        List<Matricula> matriculas = matriculaDAO.buscarPorIdAluno(2025, 1, 1);
        System.out.println("Disciplinas do Aluno 1");
        for (Matricula matricula : matriculas) {
            System.out.println(matricula.getDisciplina().getNome());
        }
        
        
        
        System.out.println("------------------");
        List<Object[]> quantidadeDisciplinasPorCurso = disciplinaDAO.quantidadePorCurso();
        System.out.println(quantidadeDisciplinasPorCurso);
        for (Object[] objects : quantidadeDisciplinasPorCurso) {
            System.out.println(objects[0] + " || " + objects[1]);
        }
    }
    
}
