package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entity.Curso;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;

/**
 *
 * @author aluno
 */
@Stateless
public class CursoDAO extends AbstractDAO<Curso>{
    
    public Curso buscarPorCodigo(Integer codigo) {
        
        EntityManager em = getEntityManager();
        return em.find(Curso.class, codigo);
    }
}
