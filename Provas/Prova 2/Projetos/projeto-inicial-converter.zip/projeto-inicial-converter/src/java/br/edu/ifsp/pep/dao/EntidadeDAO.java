package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entity.Entidade;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author aluno
 */
@Stateless
public class EntidadeDAO extends AbstractDAO<Entidade>{
    public List<Entidade> buscarTodas() {
        
        EntityManager em = getEntityManager();
        TypedQuery<Entidade> query = em.createNamedQuery("Entidade.buscarTodas", Entidade.class);
        
        return query.getResultList();
        
    }
    
    public List<Entidade> buscarPeloNome(String nome){
        EntityManager em = getEntityManager();
        
        TypedQuery<Entidade> query = em.createNamedQuery("Entidade.buscarPeloNome", Entidade.class);
        query.setParameter("nome", "%" + nome + "%");
        
        return query.getResultList();
    }
    
    public Entidade buscarPeloId(Integer id){
        EntityManager em = getEntityManager();
        return em.find(Entidade.class,id);
    }
    
}
