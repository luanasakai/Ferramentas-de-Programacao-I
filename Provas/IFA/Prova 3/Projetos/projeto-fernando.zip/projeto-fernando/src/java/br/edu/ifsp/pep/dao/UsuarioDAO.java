package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Usuario;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class UsuarioDAO extends AbstractDAO<Usuario>{
    
    
    
    public Usuario buscarLogin(String email, String senha){
        EntityManager em = getEntityManager();
        TypedQuery<Usuario> q = em.createNamedQuery("Usuario.buscarLogin",
                Usuario.class);
        
        q.setParameter("email", email);
        q.setParameter("senha", senha);
        
        return q.getSingleResult();
    }
    
    public List<Usuario> buscarTodos(){
        EntityManager em = getEntityManager();
        TypedQuery<Usuario> q = em.createNamedQuery("Usuario.buscarTodos",
                Usuario.class);
        
        return q.getResultList();
    }
    
}
