package br.edu.ifsp.pep.converter;

import br.edu.ifsp.pep.dao.CursoDAO;
import br.edu.ifsp.pep.modelo.Curso;
import jakarta.enterprise.inject.spi.CDI;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;


@FacesConverter(forClass = Curso.class)
public class CursoConverter implements Converter<Curso>{

    @Override
    public Curso getAsObject(FacesContext fc, UIComponent uic, String string) {
        if (string == null){
            return null;
        }
        CursoDAO cursoDAO = CDI.current().select(CursoDAO.class).get();
        return cursoDAO.buscarPeloId(Integer.valueOf(string));
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Curso t) {
        if (t == null || t.getCodigo() == null){
            return "";
        }
        return t.getCodigo().toString();
    }
    
}