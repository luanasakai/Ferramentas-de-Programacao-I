/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entity.Venda;
import jakarta.ejb.Stateless;

/**
 *
 * @author sakai
 */
@Stateless
public class VendaDAO extends AbstractDAO<Venda>{
    
}
