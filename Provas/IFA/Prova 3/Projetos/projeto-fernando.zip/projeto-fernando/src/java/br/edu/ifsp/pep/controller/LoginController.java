package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.UsuarioDAO;
import br.edu.ifsp.pep.modelo.Usuario;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.persistence.NoResultException;
import java.io.Serializable;
import java.util.Objects;

@Named
@SessionScoped
public class LoginController implements Serializable{
    
    @Inject
    UsuarioDAO usuarioDAO;
    
    private String email, senha;
    private Usuario usuarioLogado = null;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.usuarioDAO);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LoginController other = (LoginController) obj;
        return Objects.equals(this.usuarioDAO, other.usuarioDAO);
    }
    
    public String fazerLogin(){
        
        try {
            System.out.println("email " + email + " senha " + senha);
            Usuario u = usuarioDAO.buscarLogin(email, senha);
            usuarioLogado = u;
            Mensagem.sucesso("Login efetuado com sucesso!");
        } catch (NoResultException e) {
            Mensagem.erro("Usuario nao cadastrado.");
            System.out.println("Usuario nao cadastrado");
        }
        return "/index.xhtml";
    }
    
    
    
}
