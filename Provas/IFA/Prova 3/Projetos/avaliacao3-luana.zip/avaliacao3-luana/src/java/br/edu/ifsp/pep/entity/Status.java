package br.edu.ifsp.pep.entity;

/**
 *
 * @author aluno
 */

public enum Status {
    Ativo, Finalizado
}
