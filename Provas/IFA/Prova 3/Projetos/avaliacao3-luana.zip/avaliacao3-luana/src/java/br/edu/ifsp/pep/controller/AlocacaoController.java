package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.AlocacaoDAO;
import br.edu.ifsp.pep.dao.DesenvolvedorDAO;
import br.edu.ifsp.pep.dao.ProjetoDAO;
import br.edu.ifsp.pep.entity.Alocacao;
import br.edu.ifsp.pep.entity.Desenvolvedor;
import br.edu.ifsp.pep.entity.Projeto;
import br.edu.ifsp.pep.entity.Status;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author aluno
 */
@Named
@RequestScoped
public class AlocacaoController implements Serializable{
    
    @Inject
    private AlocacaoDAO alocacaoDAO;
    
    @Inject
    private DesenvolvedorDAO desenvolvedorDAO;
    
    @Inject
    private ProjetoDAO projetoDAO; 
    
    
    private Alocacao alocacao = new Alocacao();
    
    private Desenvolvedor desenvolvedorSelecionado;
    private Projeto projetoSeleciondo;
    
    private List<Desenvolvedor> desenvolvedores;
    private List<Projeto> projetos;
    private List<Alocacao> alocacoes;
    
    public String adicionar() {
        try{
            if(alocacaoDAO.existeAlocacaoAtiva(alocacao.getDesenvolvedor().getCodigo())){
                Mensagem.erro("Este Desenvolvedor ja esta cadastrado em uma alocacao");
                return null;
            }else{
                alocacao.setStatus(Status.Ativo);
                alocacaoDAO.inserir(alocacao);
                Mensagem.sucesso("Alocação Cadastrada!");
            
                alocacao = new Alocacao();
                return "/alocacao/lista.xhtml";     
            }                
        } catch (Exception ex) {
            Mensagem.erro(ex.getMessage());
        }
        return null;
    }
    
    public void finalizar(Alocacao alc) {
        try {
            alocacao.setStatus(Status.Finalizado);
            alocacaoDAO.alterar(alc);
            Mensagem.sucesso("Alocação finalizada com sucesso!");
        } catch (Exception e) {
            Mensagem.erro("Erro ao finalizar alocação");
        }
    }
    
    public List<Desenvolvedor> getDesenvolvedores() {
        System.out.println("metodo getDesenvolvedores");
        if (this.desenvolvedores == null) {
            System.out.println("Acessando banco de dados...");
            this.desenvolvedores = desenvolvedorDAO.buscarTodas();
        }

        return this.desenvolvedores;
    }

    public List<Projeto> getProjetos() {
        System.out.println("getProjetos");
        if (this.projetos == null) {
            System.out.println("Acessando banco de dados...");
            this.projetos = projetoDAO.buscarTodas();
        }

        return this.projetos;
    }
    
    public List<Alocacao> getAlocacoes() {
        if(alocacoes == null)
            this.alocacoes = alocacaoDAO.buscarTodas();
        return alocacoes;
    }
    
    public AlocacaoDAO getAlocacaoDAO() {
        return alocacaoDAO;
    }

    public void setAlocacaoDAO(AlocacaoDAO alocacaoDAO) {
        this.alocacaoDAO = alocacaoDAO;
    }

    public DesenvolvedorDAO getDesenvolvedorDAO() {
        return desenvolvedorDAO;
    }

    public void setDesenvolvedorDAO(DesenvolvedorDAO desenvolvedorDAO) {
        this.desenvolvedorDAO = desenvolvedorDAO;
    }

    public ProjetoDAO getProjetoDAO() {
        return projetoDAO;
    }

    public void setProjetoDAO(ProjetoDAO projetoDAO) {
        this.projetoDAO = projetoDAO;
    }

    public Alocacao getAlocacao() {
        return alocacao;
    }

    public void setAlocacao(Alocacao alocacao) {
        this.alocacao = alocacao;
    }

    public Desenvolvedor getDesenvolvedorSelecionado() {
        return desenvolvedorSelecionado;
    }

    public void setDesenvolvedorSelecionado(Desenvolvedor desenvolvedorSelecionado) {
        this.desenvolvedorSelecionado = desenvolvedorSelecionado;
    }

    public Projeto getProjetoSeleciondo() {
        return projetoSeleciondo;
    }

    public void setProjetoSeleciondo(Projeto projetoSeleciondo) {
        this.projetoSeleciondo = projetoSeleciondo;
    }

    public void setAlocacoes(List<Alocacao> alocacoes) {
        this.alocacoes = alocacoes;
    }
}
