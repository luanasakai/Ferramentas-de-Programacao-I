package br.edu.ifsp.pep.controller;

import br.edu.ifsp.pep.dao.UsuarioDAO;
import br.edu.ifsp.pep.modelo.TipoUsuario;
import br.edu.ifsp.pep.modelo.Usuario;
import br.edu.ifsp.pep.util.Mensagem;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;




@Named(value = "usuarioController")
@SessionScoped
public class UsuarioController implements Serializable{
    
    
    private List<TipoUsuario> niveis = Arrays.asList(TipoUsuario.values());
    private Usuario usuario;
    
    private List<Usuario> usuariosCadastrados;
    
    
    @Inject
    UsuarioDAO usuarioDAO;

    public Usuario getUsuario() {
        if (usuario == null){
            usuario = new Usuario();
        }
        
        
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<TipoUsuario> getNiveis() {
        return niveis;
    }

    public void setNiveis(List<TipoUsuario> niveis) {
        this.niveis = niveis;
    }

    public List<Usuario> getUsuariosCadastrados() {
        if (usuariosCadastrados == null){
            usuariosCadastrados = usuarioDAO.buscarTodos();
        }
        return usuariosCadastrados;
    }

    public void setUsuariosCadastrados(List<Usuario> usuariosCadastrados) {
        this.usuariosCadastrados = usuariosCadastrados;
    }
    
    
    
    public void cadastrar(){
        
        try {
            usuarioDAO.inserir(usuario);
            Mensagem.sucesso("Cadastrado!");
        } catch (Exception e) {
            System.out.println("erro");
        }
        
        
    }
    
    public void remover(Usuario usuario){
        
        try {
            usuarioDAO.remover(usuario);
            Mensagem.sucesso("Removido com sucesso!");
        } catch (Exception e) {
            Mensagem.erro("Ocoreu um erro");
        }
        
        
    }
    
    
    
}
