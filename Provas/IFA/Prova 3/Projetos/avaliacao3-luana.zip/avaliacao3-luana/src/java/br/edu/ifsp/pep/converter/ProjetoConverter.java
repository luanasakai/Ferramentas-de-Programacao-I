/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.pep.converter;

import br.edu.ifsp.pep.dao.ProjetoDAO;
import br.edu.ifsp.pep.entity.Projeto;
import jakarta.enterprise.inject.spi.CDI;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.inject.Inject;

/**
 *
 * @author aluno
 */
@FacesConverter(forClass = Projeto.class)
public class ProjetoConverter implements Converter<Projeto>{
    
    @Inject
    private ProjetoDAO projetoDAO;
    
    @Override
    public Projeto getAsObject(FacesContext fc, UIComponent uic, String string) {
        if(string == null){
            return null;
        }
        
        //obtem o DAO
       projetoDAO = CDI.current().select(ProjetoDAO.class).get();
        
        //buscar no BD
        return projetoDAO.buscarPeloId(Integer.valueOf(string));
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Projeto t) {
        if (t == null || t.getCodigo() == null){
            return "";
        }
        return t.getCodigo().toString();
    }
    
}
