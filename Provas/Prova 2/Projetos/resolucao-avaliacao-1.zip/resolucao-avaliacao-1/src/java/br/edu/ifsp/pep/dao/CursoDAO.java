package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entidade.Curso;
import jakarta.ejb.Stateless;

/**
 *
 * @author aluno
 */
@Stateless
public class CursoDAO extends AbstractDAO<Curso> {
    
    
    public Curso buscarPorId(Integer id) {
        return getEntityManager().find(Curso.class, id);
    }
}
