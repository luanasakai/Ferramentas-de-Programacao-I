/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package br.edu.ifsp.pep.entity;

/**
 *
 * @author sakai
 */
public enum Desconto {
    NENHUM("Sem Desconto", 0.0),
    ALUNO("Aluno (10%)", 0.10),
    PROFESSOR("Professor (15%)", 0.15),
    IDOSO("Idoso (20%)", 0.20);

    private final String descricao;
    private final double percentual;

    Desconto(String descricao, double percentual) {
        this.descricao = descricao;
        this.percentual = percentual;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getPercentual() {
        return percentual;
    }
}

