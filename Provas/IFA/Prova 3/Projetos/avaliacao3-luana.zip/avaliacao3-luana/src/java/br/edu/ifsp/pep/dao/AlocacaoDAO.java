/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entity.Alocacao;
import br.edu.ifsp.pep.entity.Status;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author aluno
 */
@Stateless
public class AlocacaoDAO extends AbstractDAO<Alocacao>{
    
     public List<Alocacao> buscarTodas() {
        
        EntityManager em = getEntityManager();
        TypedQuery<Alocacao> query = em.createNamedQuery("Alocacao.buscarTodas", Alocacao.class);
        
        return query.getResultList();
        
    }
     
     public boolean existeAlocacaoAtiva(Integer idDev) {
        try {
            EntityManager em = getEntityManager();
            List<Alocacao> resultados = em.createNamedQuery("Alocacao.existeAlocacaoAtiva", Alocacao.class)
                    .setParameter("idDev", idDev)
                    .setParameter("status", Status.Ativo)
                    .getResultList();

            // VERIFICA SE A LISTA TEM ELEMENTOS
            return !resultados.isEmpty(); // Aqui está o erro! Você estava retornando true sempre

        } catch (Exception ex) {
            ex.printStackTrace();
            return false; // Em caso de erro, considere que não existe
        }
    }
     
    public List<Alocacao> buscarAtivas() {
        EntityManager em = getEntityManager();
        List<Alocacao> query = em.createNamedQuery("Alocacao.existeAlocacaoAtiva", Alocacao.class)
                    .setParameter("status", Status.Ativo)
                    .getResultList();
        return query;
    }
}
