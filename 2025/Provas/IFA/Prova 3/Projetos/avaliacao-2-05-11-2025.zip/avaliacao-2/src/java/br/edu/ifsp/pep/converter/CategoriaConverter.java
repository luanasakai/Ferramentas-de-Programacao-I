package br.edu.ifsp.pep.converter;

import br.edu.ifsp.pep.dao.CategoriaDAO;
import br.edu.ifsp.pep.entidade.Categoria;
import jakarta.enterprise.inject.spi.CDI;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;

@FacesConverter(forClass = Categoria.class)
public class CategoriaConverter implements Converter<Categoria>{
    
    @Override
    public Categoria getAsObject(FacesContext fc, UIComponent uic, 
            String string) {
        if (string == null) {
            return null;
        }
        //Obtem o DAO
        CategoriaDAO categoriaDAO = CDI.current().select(CategoriaDAO.class).get();
        
        //Busca no BD
        return categoriaDAO.buscarPeloId(Integer.valueOf(string));
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Categoria categoria) {
        return categoria == null ? null : categoria.getId().toString();
    }
      
}
