package br.edu.ifsp.pep.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 *
 * @author aluno
 */
@Entity
@Table(name = "matricula")
@IdClass(MatriculaPK.class)
@NamedQueries(value = {
    @NamedQuery(name = "Matricula.buscarPorAluno", 
            query = "Select m FROM Matricula m "
                    + "WHERE m.ano = :ano "
                    + "AND m.semestre = :semestre "
                    + "AND m.aluno.id = :idAluno"),
    
    @NamedQuery(name = "Matricula.buscarPorAluno2", 
            query = "FROM Matricula m WHERE m.status = br.edu.ifsp.pep.entidade.StatusMatricula.Cursando AND m.aluno.id = :idAluno"),
    
})
public class Matricula implements Serializable {

    @Id
    @Column(name = "ano")
    private Integer ano;
    
    @Id
    @Column(name = "semestre")
    private Integer semestre;
    
    @Id
    @ManyToOne
    @JoinColumn(name = "aluno_id")
    private Aluno aluno;
    
    @Id
    @ManyToOne
    @JoinColumn(name = "disciplina_id")
    private Disciplina disciplina;

    @Column(name = "nota", precision = 4, scale = 2)
    private BigDecimal nota;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private StatusMatricula status;

    public Matricula() {
    }

    public Matricula(Integer ano, Integer semestre, Aluno aluno, Disciplina disciplina) {
        this.ano = ano;
        this.semestre = semestre;
        this.aluno = aluno;
        this.disciplina = disciplina;
        this.status = StatusMatricula.Cursando;
    }

    
    
    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public Integer getSemestre() {
        return semestre;
    }

    public void setSemestre(Integer semestre) {
        this.semestre = semestre;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public BigDecimal getNota() {
        return nota;
    }

    public void setNota(BigDecimal nota) {
        this.nota = nota;
    }

    public StatusMatricula getStatus() {
        return status;
    }

    public void setStatus(StatusMatricula status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.ano);
        hash = 29 * hash + Objects.hashCode(this.semestre);
        hash = 29 * hash + Objects.hashCode(this.aluno);
        hash = 29 * hash + Objects.hashCode(this.disciplina);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Matricula other = (Matricula) obj;
        if (!Objects.equals(this.ano, other.ano)) {
            return false;
        }
        if (!Objects.equals(this.semestre, other.semestre)) {
            return false;
        }
        if (!Objects.equals(this.aluno, other.aluno)) {
            return false;
        }
        return Objects.equals(this.disciplina, other.disciplina);
    }

    @Override
    public String toString() {
        return "Matricula{" + "ano=" + ano + ", semestre=" + semestre + ", aluno=" + aluno + ", disciplina=" + disciplina + ", nota=" + nota + ", status=" + status + '}';
    }

}
