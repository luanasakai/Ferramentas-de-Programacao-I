/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsp.pep.converter;

import br.edu.ifsp.pep.dao.DesenvolvedorDAO;
import br.edu.ifsp.pep.entity.Desenvolvedor;
import jakarta.enterprise.inject.spi.CDI;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.inject.Inject;

/**
 *
 * @author aluno
 */
@FacesConverter(forClass = Desenvolvedor.class)
public class DesenvolvedorConverter implements Converter<Desenvolvedor>{
    
    @Inject
    private DesenvolvedorDAO desenvolvedorDAO;
    
    @Override
    public Desenvolvedor getAsObject(FacesContext fc, UIComponent uic, String string) {
        if(string == null){
            return null;
        }
        
        //obtem o DAO
        desenvolvedorDAO = CDI.current().select(DesenvolvedorDAO.class).get();
        
        //buscar no BD
        return desenvolvedorDAO.buscarPeloId(Integer.valueOf(string));
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Desenvolvedor t) {
        if (t == null || t.getCodigo() == null){
            return "";
        }
        return t.getCodigo().toString();
    }
    
}
