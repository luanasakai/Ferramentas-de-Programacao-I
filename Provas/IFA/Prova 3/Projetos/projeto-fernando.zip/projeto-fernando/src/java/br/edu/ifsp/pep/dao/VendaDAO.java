package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Venda;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class VendaDAO extends AbstractDAO<Venda>{
    
    public List<Venda> buscarTodos(){
        EntityManager em = getEntityManager();
        TypedQuery<Venda> q = em.createNamedQuery("Venda.buscarTodos",
                Venda.class);
        return q.getResultList();
    }
    
}
