package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entidade.Aluno;
import br.edu.ifsp.pep.entidade.Curso;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author aluno
 */
@Stateless
public class AlunoDAO extends AbstractDAO<Aluno> {
    
    public List<Aluno> buscarPorCurso(Curso curso) {
        EntityManager em = getEntityManager();
        TypedQuery<Aluno> query = em.createNamedQuery("Aluno.buscarPorCurso", Aluno.class);
        query.setParameter("curso", curso);
        
        return query.getResultList();
    }
    public List<Aluno> buscarPorIdCurso(Integer idCurso) {
        EntityManager em = getEntityManager();
        TypedQuery<Aluno> query = em.createNamedQuery("Aluno.buscarPorIdCurso", Aluno.class);
        query.setParameter("idCurso", idCurso);
        
        return query.getResultList();
    }
    
}
