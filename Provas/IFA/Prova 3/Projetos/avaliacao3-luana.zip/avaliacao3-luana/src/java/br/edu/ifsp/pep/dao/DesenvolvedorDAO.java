package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.entity.Desenvolvedor;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author aluno
 */
@Stateless
public class DesenvolvedorDAO extends AbstractDAO<Desenvolvedor>{
    
    public List<Desenvolvedor> buscarTodas() {
        
        EntityManager em = getEntityManager();
        TypedQuery<Desenvolvedor> query = em.createNamedQuery("Desenvolvedor.buscarTodas", Desenvolvedor.class);
        
        return query.getResultList();
        
    }
    
    public Desenvolvedor buscarPeloId(Integer id){
        EntityManager em = getEntityManager();
        return em.find(Desenvolvedor.class, id);
    }
}
