package br.edu.ifsp.pep.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author aluno
 */
@Entity
@Table(name = "alocacao")
@IdClass(AlocacaoPK.class)
@NamedQueries(value = {
    @NamedQuery(name = "Alocacao.buscarTodas", query = "FROM Alocacao a"),
    @NamedQuery(//nao deixa alocar em um projeto especifico
        name = "Alocacao.existeAlocacao",
        query = "SELECT a FROM Alocacao a " +
                "WHERE a.desenvolvedor.codigo = :idDev " +
                "AND a.projeto.codigo = :idProj"
    ),
    @NamedQuery(
        name = "Alocacao.existeAlocacaoAtiva",
        query = "SELECT a FROM Alocacao a " +
                "WHERE a.desenvolvedor.codigo = :idDev " +
                "AND a.status = :status"
    ),
     @NamedQuery(
        name = "Alocacao.alocacaoAtiva",
        query = "SELECT a FROM Alocacao a WHERE a.status = :status"
    )
        
})
public class Alocacao implements Serializable{
    
    @Id
    @ManyToOne
    @JoinColumn(name = "desenvolvedor")
    private Desenvolvedor desenvolvedor;
    
    @Id
    @ManyToOne
    @JoinColumn(name = "projeto")
    private Projeto projeto;
    
    @Column(name = "horas_semanais", nullable = false)
    private int horas_semanais;
    
    @Column(name = "valor_hora", nullable = false)
    private Double valor_hora;
    
    @Column(name = "status", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

    public Desenvolvedor getDesenvolvedor() {
        return desenvolvedor;
    }

    public void setDesenvolvedor(Desenvolvedor desenvolvedor) {
        this.desenvolvedor = desenvolvedor;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    public int getHoras_semanais() {
        return horas_semanais;
    }

    public void setHoras_semanais(int horas_semanais) {
        this.horas_semanais = horas_semanais;
    }

    public Double getValor_hora() {
        return valor_hora;
    }

    public void setValor_hora(Double valor_hora) {
        this.valor_hora = valor_hora;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Alocacao{" + "desenvolvedor=" + desenvolvedor + ", projeto=" + projeto + ", horas_semanais=" + horas_semanais + ", valor_hora=" + valor_hora + ", status=" + status + '}';
    } 
}
